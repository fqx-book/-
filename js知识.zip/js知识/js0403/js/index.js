console.log("我是js代码");
var name ='张三丰';

/* 函数 */
function hi(){
	console.log("我是张三丰");
}
hi();
