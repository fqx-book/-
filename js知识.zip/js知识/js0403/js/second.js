console.log("我是第二个js文件");

console.log(name);

/* 调用index.js的函数 */
hi();