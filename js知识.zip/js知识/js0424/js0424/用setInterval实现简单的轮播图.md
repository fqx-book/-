# 1.用setInterval实现简单的轮播图



![image-20200424114921490](%E7%94%A8setInterval%E5%AE%9E%E7%8E%B0%E7%AE%80%E5%8D%95%E7%9A%84%E8%BD%AE%E6%92%AD%E5%9B%BE.assets/image-20200424114921490.png)

